import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class Drinks {
        //preferences template: sweet, mocha, caramel, hazelnut, caffiene
        public static String compareDrink(int[] array) {
                List<int[]> drinks = new ArrayList<>();
                int[] mocha = {1, 1, 0, 0, 0};
                int[] caramelLatte = {1, 0, 1, 0, 0};
                int [] hazelnutLatte = {1, 0, 0, 1, 0};
                //ARRAY LIST TO ADD DRINKS

                drinks.add(mocha);
                drinks.add(caramelLatte);
                drinks.add(hazelnutLatte);
                //ARRAY LIST TO ADD DRINKS

                Map<String, int[]> drinkMap = new HashMap<>();
                drinkMap.put("Mocha", mocha);
                drinkMap.put("Caramel Latte", caramelLatte);
                drinkMap.put("Hazelnut Latte",hazelnutLatte);
                //MAP TO ADD DRINKS

                int highestMatch = 0;
                String matchedDrink = "";
                for (int i = 0; i < drinks.size(); i++) {
                        int[] drink = drinks.get(i);
                        int matchNum = 0;
                        for (int j = 0; j < array.length; j++) {
                                if (array[j] == drink[j]) {
                                        matchNum++;
                                }
                        }
                        if (matchNum > highestMatch) {
                                highestMatch = matchNum;
                                matchedDrink = getDrinkName(drinkMap, drink);
                        }
                }
                return matchedDrink;
        }
        public static String getDrinkName(Map<String, int[]> drinkMap, int[] drinkArray) {
                for (Map.Entry<String, int[]> entry : drinkMap.entrySet()) {
                        if (Arrays.equals(entry.getValue(), drinkArray)) {
                                return entry.getKey();
                        }
                }
                return null; // Handle the case where the drink name is not found
        }
        public static void main(String[] args) {

        }//end of main
}//end of drinks class
