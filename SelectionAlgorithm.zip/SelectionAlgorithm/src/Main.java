//The main class; which would handle making a request to the database,
//then assigning the retreived data to tbe user class, which would then in turn have its data ran through
//by this main class, sending a result to
public class Main {
    public static void main(String[] args) {
        User user1 = new User("will", "123hey", 1,1,0,0,0);
        //create a user object(in actuality, these values would then be filled in by the database)
        //preferences template: sweet, mocha, caramel, hazelnut, caffiene

            int[] userPreferences = user1.getPref();
            //call the function that gets the user's preferences
        //^^get the user's preferences as a string of 1s and 0s^^(DONE)

            String bestDrink = user1.compareDrink(userPreferences);

            System.out.println("Your recommended drink is " + bestDrink);
        //compare this string with every drink's string of 1's and 0's

        //return the drink with the highest match to the console
    }//end of function main
}//end of main class