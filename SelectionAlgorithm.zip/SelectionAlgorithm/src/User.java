//User Section. Stores User with username + password + all integer preferences

public class User extends Drinks{
    String userName;
    String password;
    int pref1;
    int pref2;
    int pref3;
    int pref4;
    int pref5;

    //variables section

    public User(String userName, String Password, int pref1, int pref2, int pref3, int pref4, int pref5){
        this.userName = userName;
        this.password = password;
        this.pref1 = pref1;
        this.pref2 = pref2;
        this.pref3 = pref3;
        this.pref4 = pref4;
        this.pref5 = pref5;
    }//end of user constructor

    public int[] getPref() {
        String userString = userName + password + pref1 + pref2 + pref3 + pref4 + pref5;
        String lastFiveDigitsString = userString.substring(userString.length() - 5);

        int[] lastFiveDigitsArray = new int[5];
        for (int i = 0; i < 5; i++) {
            lastFiveDigitsArray[i] = Integer.parseInt(String.valueOf(lastFiveDigitsString.charAt(i)));
        }

        return lastFiveDigitsArray;
    }

}//end of User class
